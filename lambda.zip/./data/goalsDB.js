"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const baseDB_1 = require("./baseDB");
const listGoals_1 = require("../business/entities/listGoals");
class GoalsDB extends baseDB_1.BaseDB {
    constructor() {
        super(...arguments);
        this.goalsTableName = "goals";
        //
    }
    createGoal(goal) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.connection.insert({
                id: goal.getId(),
                goal: goal.getGoal(),
                userId: goal.getUserId()
            }).into(this.goalsTableName);
        });
    }
    getGoals(userId) {
        return __awaiter(this, void 0, void 0, function* () {
            const goals = yield this.connection
                .select('goals.*')
                .from(this.goalsTableName)
                .where({ userId });
            // await this.connection
            // .select('goals.*')
            // .from(this.goalsTableName)
            // .where({userId}) 
            // .and(token)
            return goals.map((goal) => {
                return new listGoals_1.ListGoals(goal.id, goal.goal, goal.userId);
            });
        });
    }
    updateGoal(id, newGoal, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield this.connection.raw(`
                UPDATE goals SET goal = '${newGoal}'
                WHERE id='${id}' 
                AND userId='${userId}'
               
            `);
            }
            catch (err) {
                console.log(err);
                throw err;
            }
        });
    }
    deleteGoal(goalId, token) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield this.connection.raw(`
                DELETE FROM ${this.goalsTableName}
                WHERE id='${goalId}'
                AND userId='${token}';
            `);
            }
            catch (err) {
                console.log(err);
                throw err;
            }
        });
    }
}
exports.GoalsDB = GoalsDB;
