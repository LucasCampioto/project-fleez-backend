"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const goals_1 = require("./goals");
class ListGoals extends goals_1.Goals {
    constructor(id, goal, userId) {
        super(id, goal, userId);
    }
}
exports.ListGoals = ListGoals;
