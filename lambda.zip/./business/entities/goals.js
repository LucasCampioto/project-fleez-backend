"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Goals {
    constructor(id, goal, userId) {
        this.id = id;
        this.goal = goal;
        this.userId = userId;
    }
    getId() {
        return this.id;
    }
    getGoal() {
        return this.goal;
    }
    getUserId() {
        return this.userId;
    }
}
exports.Goals = Goals;
