"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const signUp_1 = require("./endpoints/user/signUp");
const login_1 = require("./endpoints/user/login");
const createGoal_1 = require("./endpoints/goals/createGoal");
const listGoals_1 = require("./endpoints/goals/listGoals");
const updateGoal_1 = require("./endpoints/goals/updateGoal");
const deleteGoal_1 = require("./endpoints/goals/deleteGoal");
const app = express_1.default();
app.use(cors_1.default());
app.use(express_1.default.json()); // Linha mágica (middleware)
app.post('/singup', signUp_1.signUpEndpoint);
app.post('/login', login_1.loginEndpoint);
app.post('/create/goal', createGoal_1.createGoalEndpoint);
app.get('/listGoals', listGoals_1.listGoalsEndpoint);
app.post('/goal/update/:id', updateGoal_1.updateGoalEndpoint);
app.delete('/goal/delete/:goalId', deleteGoal_1.deleteGoalEndpoint);
exports.default = app;
